"""Generic HTML response URL extractor for the Android stream player.

This file is intentionally independent from the existing tool.py.
It does not depend on a domain, PHP, a fixed HTML tag, or a fixed variable name.

Expected payload shape:
{
    "url": "https://source.example/page",
    "final_url": "https://source.example/page",
    "content_type": "text/html; charset=utf-8",
    "body": "<html>...</html>",
    "headers": {"Content-Type": "text/html"}
}

Public interface:
    should_handle(payload) -> bool
    resolve(payload) -> dict

The result contains every discovered absolute URL in `urls`, plus useful
categories in `stream_urls`, `manifest_urls`, and `media_urls`.
"""
from __future__ import annotations

import html
import json
import re
import os
import time
import traceback
from typing import Any
from urllib.parse import unquote, urljoin, urlparse


_STATUS_RESULT = "RESULT"
_STATUS_PASS = "PASS"
_STATUS_ERROR = "ERROR"

# TEMPORARY DIAGNOSTICS FOR THIS TOOL ONLY
_DIAG_LOG = "tool_diagnostic_report.jsonl"
_DIAG_HTML = "tool_latest_html_response.html"

def _diag_path(name: str) -> Path:
    # Dynamic tools are loaded from the app private python_runtime directory.
    # The fallback covers the bundled Android package layout.
    candidates = [
        Path(__file__).resolve().parent,
        Path("/data/data/com.streamplayer.app/files/python_runtime"),
    ]
    for folder in candidates:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            return folder / name
        except Exception:
            continue
    return Path(name)

def _diag(event: str, **data: Any) -> None:
    try:
        record = {
            "time": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "event": event,
            **data,
        }
        with _diag_path(_DIAG_LOG).open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass

def _save_diag_html(payload: dict[str, Any]) -> None:
    try:
        body = payload.get("body", payload.get("response_body", ""))
        _diag_path(_DIAG_HTML).write_text(str(body), encoding="utf-8")
    except Exception as exc:
        _diag("html_snapshot_error", error=str(exc), traceback=traceback.format_exc())

# Absolute URLs. The expression deliberately stops at common HTML/JS delimiters.
_ABSOLUTE_URL_RE = re.compile(
    r"(?i)(?:https?://|rtmp://|rtsp://|udp://|srt://)[^\s\"'<>`\\]+"
)

# Protocol-relative URLs, such as //cdn.example/live/index.m3u8.
_PROTOCOL_RELATIVE_RE = re.compile(r"(?i)(?<!:)//[^\s\"'<>`\\]+")

# Values in src/href/action/data-* and similar HTML attributes.
_ATTRIBUTE_RE = re.compile(
    r"(?is)\b(?:href|src|action|poster|content|value|url|srcset|file|source|stream|manifest|video|audio|playlist|mpd|m3u8)\s*=\s*"
    r"(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))"
)

# CSS and JavaScript url(...).
_CSS_URL_RE = re.compile(r"(?is)\burl\s*\(\s*[\"']?([^\"')\s]+)")

# HTML comments and script/style blocks are kept on purpose: URLs are often there.
_MEDIA_EXTENSIONS = (
    ".m3u8", ".m3u", ".mpd", ".mp4", ".webm", ".mkv", ".ts", ".m4s",
    ".aac", ".mp3", ".flv", ".mov", ".avi", ".ism", ".f4m",
)
_MANIFEST_EXTENSIONS = (".m3u8", ".m3u", ".mpd", ".f4m", ".ism")


def _parse_rget(value: Any) -> tuple[str, dict[str, str]]:
    """Parse an Rget value only when this function is explicitly called.

    This helper is independent from the HTML response path: it does not
    inspect HTML, fetch URLs, or extract playback links.
    """
    raw = str(value or "").strip()
    if not raw.startswith("Rget@"):
        raise ValueError("unsupported resolver prefix")

    # h. و |h. فواصل خاصة بصيغة Rget وليست جزءاً من اسم الـ Header.
    parts = re.split(r"(?:\|)?h\.", raw)
    target_url = parts[0][len("Rget@"):].strip()
    if not target_url:
        raise ValueError("empty Rget URL")

    headers: dict[str, str] = {}
    for part in parts[1:]:
        if "=" not in part:
            continue
        name, encoded_value = part.split("=", 1)
        name = name.strip()
        if name:
            headers[name] = unquote(encoded_value.strip())
    return target_url, headers


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _looks_like_html(body: str, content_type: str) -> bool:
    ctype = content_type.lower()
    if "text/html" in ctype or "application/xhtml" in ctype:
        return True

    sample = body.lstrip("\ufeff \t\r\n").lower()
    return (
        sample.startswith("<!doctype html")
        or sample.startswith("<html")
        or "<head" in sample
        or "<body" in sample
        or "<script" in sample
        or "<meta " in sample
    )


def _decode_escaped_text(value: str) -> str:
    """Decode common JSON/JavaScript/HTML escaping without assuming a format."""
    result = value

    # A page can contain escaped text inside another escaped JSON/JS string.
    for _ in range(4):
        previous = result

        result = html.unescape(result)
        result = re.sub(
            r"\\u\{([0-9a-fA-F]{1,6})\}",
            lambda m: chr(int(m.group(1), 16)),
            result,
        )
        result = re.sub(
            r"\\u([0-9a-fA-F]{4})",
            lambda m: chr(int(m.group(1), 16)),
            result,
        )
        result = re.sub(
            r"\\x([0-9a-fA-F]{2})",
            lambda m: chr(int(m.group(1), 16)),
            result,
        )
        result = result.replace("\\/", "/")
        result = result.replace("\\:", ":")

        if result == previous:
            break

    return result


def _clean_candidate(value: str) -> str:
    value = _decode_escaped_text(value).strip()
    value = value.strip("\"'`.,;:)]}>")
    value = value.replace("\\\"", '"').replace("\\'", "'")
    return value


def _is_url(value: str) -> bool:
    parsed = urlparse(value)
    return bool(parsed.scheme and parsed.netloc)


def _normalise_candidate(value: str, base_url: str) -> str:
    value = _clean_candidate(value)
    if not value or value.startswith(("#", "data:", "javascript:", "mailto:", "tel:")):
        return ""

    # Ignore obvious non-URL tokens captured from JavaScript/CSS.
    if value.startswith(("\\u", "\\x")):
        return ""

    if value.startswith("//"):
        scheme = urlparse(base_url).scheme or "https"
        value = f"{scheme}:{value}"
    elif not _is_url(value):
        # Keep relative links too, but resolve them when a valid base exists.
        if not base_url:
            return ""
        value = urljoin(base_url, value)

    return value if _is_url(value) else ""


def _collect_raw_values(body: str) -> list[str]:
    decoded = _decode_escaped_text(body)
    values: list[str] = []

    # Search the original and decoded versions. This catches both literal and
    # escaped URLs while de-duplication later preserves the first-seen order.
    for text in (body, decoded):
        values.extend(match.group(0) for match in _ABSOLUTE_URL_RE.finditer(text))
        values.extend(match.group(0) for match in _PROTOCOL_RELATIVE_RE.finditer(text))

        for match in _ATTRIBUTE_RE.finditer(text):
            values.extend(group for group in match.groups() if group)

        values.extend(match.group(1) for match in _CSS_URL_RE.finditer(text))

    return values


def extract_all_urls(body: str, base_url: str = "") -> list[str]:
    """Return every unique absolute/absolute-resolved URL found in the body."""
    output: list[str] = []
    seen: set[str] = set()

    # First pass catches complete URLs anywhere, including meta tags and scripts.
    for raw in _collect_raw_values(body):
        candidate = _normalise_candidate(raw, base_url)
        if candidate and candidate not in seen:
            seen.add(candidate)
            output.append(candidate)

    return output


def _looks_like_media(url: str) -> bool:
    path = urlparse(url).path.lower()
    return path.endswith(_MEDIA_EXTENSIONS) or any(
        token in url.lower()
        for token in (".m3u8?", ".mpd?", ".m3u?", ".ts?", ".mp4?")
    )


def _looks_like_manifest(url: str) -> bool:
    path = urlparse(url).path.lower()
    return path.endswith(_MANIFEST_EXTENSIONS) or any(
        token in url.lower() for token in (".m3u8?", ".mpd?", ".m3u?")
    )


def should_handle_html(payload: dict[str, Any]) -> bool:
    """Handle only when the player actually supplied an HTML response body."""
    if not isinstance(payload, dict):
        return False

    body = _as_text(payload.get("body", payload.get("response_body", "")))
    headers = payload.get("headers") or {}
    content_type = _as_text(payload.get("content_type", ""))
    if isinstance(headers, dict):
        content_type = content_type or _as_text(
            headers.get("Content-Type", headers.get("content-type", ""))
        )

    return bool(body) and _looks_like_html(body, content_type)


def resolve_html(payload: dict[str, Any]) -> dict[str, Any]:
    """Extract all URLs from an HTML response without relying on its domain."""
    _diag("html_resolve_start", payload_type=type(payload).__name__)
    if isinstance(payload, dict):
        _save_diag_html(payload)
        _diag("html_payload", url=payload.get("url", ""),
              final_url=payload.get("final_url", ""),
              content_type=payload.get("content_type", ""),
              body_length=len(str(payload.get("body", payload.get("response_body", "")))),
              payload_keys=sorted(payload.keys()))
    if not isinstance(payload, dict):
        return {"status": _STATUS_ERROR, "message": "payload must be an object"}

    body = _as_text(payload.get("body", payload.get("response_body", "")))
    source_url = _as_text(payload.get("final_url", payload.get("url", ""))).strip()

    if not body:
        return {
            "status": _STATUS_PASS,
            "final_url": source_url,
            "urls": [],
            "stream_urls": [],
            "manifest_urls": [],
            "media_urls": [],
        }

    all_urls = extract_all_urls(body, source_url)
    manifest_urls = [url for url in all_urls if _looks_like_manifest(url)]
    _diag("html_extraction", source_url=source_url, total_urls=len(all_urls),
          manifest_urls=manifest_urls, all_urls=all_urls)
    media_urls = [url for url in all_urls if _looks_like_media(url)]

    # Prefer a manifest, then another media URL, while still returning every URL.
    stream_urls = list(dict.fromkeys(manifest_urls + media_urls))
    selected = stream_urls[0] if stream_urls else source_url

    return {
        "status": _STATUS_RESULT,
        "final_url": selected,
        "urls": all_urls,
        "stream_urls": stream_urls,
        "manifest_urls": manifest_urls,
        "media_urls": media_urls,
        "source_url": source_url,
    }


# ------------------------------ Rget path ------------------------------
# This path is selected only for an Rget@ input. It never runs for an HTML
# response payload, and the HTML path never calls it.
_RGET_PREFIX = "Rget@"


def _parse_rget(value: Any) -> tuple[str, dict[str, str]]:
    """Convert Rget@...|h.Name=urlencoded into URL and decoded headers."""
    raw = str(value or "").strip()
    _diag("rget_parse_start", value=raw)
    if not raw.startswith(_RGET_PREFIX):
        raise ValueError("unsupported resolver prefix")

    parts = re.split(r"(?:\|)?h\.", raw)
    target_url = parts[0][len(_RGET_PREFIX):].strip()
    if not target_url:
        raise ValueError("empty Rget URL")

    headers: dict[str, str] = {}
    for part in parts[1:]:
        if "=" not in part:
            continue
        name, encoded_value = part.split("=", 1)
        name = name.strip()
        if name:
            headers[name] = unquote(encoded_value.strip())
    _diag("rget_parse_result", target_url=target_url, headers=headers)
    return target_url, headers


def resolve_rget(payload: dict[str, Any]) -> dict[str, Any]:
    """Unwrap one Rget input and return it immediately; never fetch it."""
    try:
        _diag("rget_resolve_start", payload_keys=sorted(payload.keys()), url=payload.get("url", ""))
        target_url, incoming_headers = _parse_rget(payload.get("url", ""))
        result = {
            "status": _STATUS_RESULT,
            "final_url": target_url,
            "headers": incoming_headers,
        }
        _diag("rget_resolve_result", status=result["status"], final_url=target_url,
              header_names=sorted(incoming_headers.keys()))
        return result
    except Exception as exc:
        _diag("rget_resolve_error", error=str(exc), traceback=traceback.format_exc())
        return {"status": _STATUS_ERROR, "message": "تعذر تحليل رابط Rget"}


def should_handle(payload: dict[str, Any]) -> bool:
    """Dispatch detection: Rget input or an already supplied HTML response."""
    url = str(payload.get("url", "")).strip() if isinstance(payload, dict) else ""
    if url.startswith(_RGET_PREFIX):
        _diag("dispatch", route="rget", url=url)
        return True
    handled = should_handle_html(payload)
    _diag("dispatch", route="html" if handled else "pass", url=url, handled=handled)
    return handled


def resolve(payload: dict[str, Any]) -> dict[str, Any]:
    """Dispatch only the matching independent path."""
    url = str(payload.get("url", "")).strip() if isinstance(payload, dict) else ""
    if url.startswith(_RGET_PREFIX):
        _diag("resolve_dispatch", route="rget", url=url)
        return resolve_rget(payload)
    _diag("resolve_dispatch", route="html", url=url)
    return resolve_html(payload)
