"""Generic Rget parser for StreamPlayer.

Input format:
    Rget@http(s)://example.com/path|h.Header-Name=urlencoded_value|h.Other=value

The tool does not fetch the URL and does not extract streamUrl. It only returns
that URL and the decoded headers to the Android player.
"""
from __future__ import annotations

import re
from urllib.parse import unquote


RGET_PREFIX = "Rget@"


def should_handle(payload):
    """Handle every input whose value starts with Rget@."""
    return str(payload.get("url", "")).strip().startswith(RGET_PREFIX)


def _parse_rget(value):
    """Return (target_url, headers) from a generic Rget value."""
    raw = str(value or "").strip()
    if not raw.startswith(RGET_PREFIX):
        raise ValueError("unsupported resolver prefix")

    # |h. and h. are separators only; neither becomes part of a header name.
    parts = re.split(r"(?:\|)?h\.", raw)
    target_url = parts[0][len(RGET_PREFIX):].strip()
    if not re.match(r"^https?://[^\s]+$", target_url, flags=re.IGNORECASE):
        raise ValueError("Rget target must be an http or https URL")

    headers = {}
    for part in parts[1:]:
        if "=" not in part:
            continue
        name, encoded_value = part.split("=", 1)
        name = name.strip()
        if not name:
            continue
        # Decode URL-encoded values, while leaving ordinary values unchanged.
        headers[name] = unquote(encoded_value.strip())
    return target_url, headers


def resolve(payload):
    """Return the original HTTP(S) URL and decoded headers to the player."""
    try:
        target_url, headers = _parse_rget(payload.get("url", ""))
        return {
            "status": "RESULT",
            "final_url": target_url,
            "headers": headers,
        }
    except Exception as exc:
        return {
            "status": "ERROR",
            "message": str(exc) or "تعذر تحليل رابط Rget",
        }
