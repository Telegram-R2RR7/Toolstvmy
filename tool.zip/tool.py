"""Resolver for wideiptv Rget stream URLs.

Input format:
    Rget@https://wideiptv.top/player/beINAR|h.User-Agent=<urlencoded>|h.Referer=<urlencoded>

The player calls should_handle first, then resolve only for matching URLs.
"""
from __future__ import annotations

import html
import json
import re
from urllib.parse import unquote

import requests

PREFIX = "Rget@https://wideiptv.top/player/beINAR"
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/153.0.0.0 Safari/537.36"
)
ORIGIN = "https://wideiptv.top"
FINAL_REFERER = "https://wideiptv.top/"


def should_handle(payload):
    """Return True only for the requested Rget wideiptv URL family."""
    url = str(payload.get("url", "")).strip()
    return url.startswith(PREFIX)


def _parse_rget(value):
    """Convert Rget@...|h.Name=urlencoded into URL and decoded headers."""
    raw = str(value or "").strip()
    if not raw.startswith("Rget@"):
        raise ValueError("unsupported resolver prefix")

    # h. و |h. فواصل خاصة بصيغة Rget وليست جزءاً من اسم الـ Header.
    # بعد هذه العملية تصبح المفاتيح User-Agent وReferer وOrigin فقط.
    parts = re.split(r"(?:\|)?h\.", raw)
    target_url = parts[0][len("Rget@"):].strip()
    if not target_url:
        raise ValueError("empty Rget URL")

    headers = {}
    for part in parts[1:]:
        if "=" not in part:
            continue
        name, encoded_value = part.split("=", 1)
        name = name.strip()
        if name:
            headers[name] = unquote(encoded_value.strip())
    return target_url, headers


def _extract_stream_url(page):
    """Extract and JavaScript-unescape streamUrl: \"...\" from HTML."""
    match = re.search(
        r"\bstreamUrl\s*:\s*(['\"])((?:\\.|(?!\1).)*?)\1",
        page,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        match = re.search(
            r"\bstreamUrl\s*=\s*(['\"])((?:\\.|(?!\1).)*?)\1",
            page,
            flags=re.IGNORECASE | re.DOTALL,
        )
    if not match:
        return ""

    encoded = match.group(2)
    try:
        # JSON string decoding correctly handles \/, \" and escaped backslashes.
        value = json.loads('"' + encoded.replace('"', '\\"') + '"')
    except Exception:
        value = encoded.replace("\\/", "/").replace('\\"', '"').replace("\\\\", "\\")
    return html.unescape(value).strip()


def resolve(payload):
    """Fetch the Rget HTML and return the final stream URL for ExoPlayer."""
    try:
        target_url, incoming_headers = _parse_rget(payload.get("url", ""))
        request_user_agent = incoming_headers.get("User-Agent") or DEFAULT_USER_AGENT
        request_headers = dict(incoming_headers)
        request_headers["User-Agent"] = request_user_agent

        response = requests.get(
            target_url,
            headers=request_headers,
            timeout=(10, 25),
        )
        response.raise_for_status()
        final_url = _extract_stream_url(response.text)

        if not final_url or not final_url.lower().startswith(("http://", "https://")):
            return {
                "status": "ERROR",
                "message": "لم يتم العثور على streamUrl صالح"
            }

        return {
            "status": "RESULT",
            "final_url": final_url,
            "headers": {
                "Origin": ORIGIN,
                "Referer": FINAL_REFERER,
                "Accept": "*/*",
                "User-Agent": request_user_agent,
            },
        }
    except requests.RequestException:
        return {
            "status": "ERROR",
            "message": "تعذر الاتصال بمصدر الرابط"
        }
    except Exception:
        return {
            "status": "ERROR",
            "message": "تعذر تجهيز الرابط"
        }
